package csc311;
import java.util.Iterator;

import net.datastructures.Position;
import net.datastructures.PositionalList;


public class DoublyLinkedList<E> implements PositionalList<E> {

	private Node<E> head;
	private Node<E> tail;
	private int sz = 0;
	
	public DoublyLinkedList() {
		// TODO Auto-generated constructor stub
		
		head = new Node<E>(null, null, null);
		tail = new Node<E>(null, head, null);
		head.setNext(tail);
	}

	private Node<E> validate(Position<E> p) throws IllegalArgumentException {
		if(!(p instanceof Node)) {
			throw new IllegalArgumentException("Invalid Position");
		}
		Node<E> node = (Node<E>) p;
		if(node.getNext() == null) {
			throw new IllegalArgumentException("Position is no longer in list");
		}
		return node;
	}
	
	private Position<E> position(Node<E> node) {
		if(node == head || node == tail) {
			return null;
		}
		return node;
	}
	
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return sz;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return sz == 0;
	}

	@Override
	public Position<E> first() {
		// TODO Auto-generated method stub
		return position(head.getNext());
	}

	@Override
	public Position<E> last() {
		// TODO Auto-generated method stub
		return position(tail.getPrev());
	}

	@Override
	public Position<E> before(Position<E> p) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = validate(p);
		return position(node.getPrev());
	}

	@Override
	public Position<E> after(Position<E> p) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = validate(p);
		return position(node.getNext());
	}
	
	private Position<E> addBetween(E e, Node<E> p, Node <E> s) {
		Node<E> newNode = new Node<E>(e, p, s);
		p.setNext(newNode);
		s.setPrev(newNode);
		sz++;
		return newNode;
	}

	@Override
	public Position<E> addFirst(E e) {
		// TODO Auto-generated method stub
		return addBetween(e, head, head.getNext());
	}

	@Override
	public Position<E> addLast(E e) {
		// TODO Auto-generated method stub
		return addBetween(e, tail.getPrev(), tail);
		
	}

	@Override
	public Position<E> addBefore(Position<E> p, E e)
			throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = validate(p);
		return addBetween(e, node.getPrev(), node);
	}

	@Override
	public Position<E> addAfter(Position<E> p, E e)
			throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = validate(p);
		return addBetween(e, node, node.getNext());
	}

	@Override
	public E set(Position<E> p, E e) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = validate(p);
		E ans = node.getElement();
		node.setElement(e);
		return ans;
	}

	@Override
	public E remove(Position<E> p) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = validate(p);
		Node<E> prev = node.getPrev();
		Node<E> next = node.getNext();
		
		prev.setNext(next);
		next.setPrev(prev);
		sz--;
		
		E ans = node.getElement();
		node.setElement(null);
		node.setNext(null);
		node.setPrev(null);
		return ans;
	}

	private class PositionIterator implements Iterator<Position<E>> {
		private Position<E> cursor = first();
		private Position<E> recent = null;
		
		public boolean hasNext() {
			return(cursor != null);
		}
		
		public Position<E> next() throws IndexOutOfBoundsException {
			if(cursor == null) {
				throw new IndexOutOfBoundsException("nothing left");
				}
			recent = cursor;
			cursor = after(cursor);
			return recent;
		}
	
	public void remove() throws IllegalStateException {
		if(recent == null) {
			throw new IllegalStateException("nothing left to remove");	
		}
		DoublyLinkedList.this.remove(recent);
		recent = null;
		}
	
	private class PositionIterable implements Iterable<Position <E>> {
		public Iterator<Position<E>> iterator() {
			return new PositionIterator();
		}
	}
	
	public Iterable<Position<E>> positions() {
		return new PositionIterable();
	}
	
	private class ElementIterator implements Iterator<E> {
		Iterator<Position<E>> posIterator = new PositionIterator();
		
		public boolean hasNext() {
			return posIterator.hasNext();
		}
		
		public E next() {
			return posIterator.next().getElement();
		}
	}
	
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return new ElementIterator();
	}

	
	public E removeFirst() throws IllegalArgumentException {
		// TODO Auto-generated method stub
		if(isEmpty()) {
			throw new IllegalArgumentException("List empty");
		}
		return DoublyLinkedList.this.remove(first());
	}
	
	public E removeLast() throws IllegalArgumentException {
		// TODO Auto-generated method stub
		if(isEmpty()) {
			throw new IllegalArgumentException("List empty");
		}
		return DoublyLinkedList.this.remove(last());
	}	
	}
	private static class Node<E> implements Position<E> {
		private E elem;
		private Node<E> prev;
		private Node<E> next;
		
		public Node(E e, Node<E> p, Node<E> n) {
			elem = e;
			prev = p;
			next = n;
		}
		
		public E getElement() throws IllegalStateException {
			if(next == null) {
				throw new IllegalStateException("Position no longer valid");
			}
			return elem;
		}
		
		public Node<E> getPrev() {
			return prev;
		}
		
		public Node<E> getNext() {
			return next;
		}
		
		public void setElement(E e) {
			elem = e;
		}
		
		public void setPrev(Node<E> p) {
			prev = p;
		}
		
		public void setNext(Node<E> n) {
			next = n;
		}
	}
	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Position<E>> positions() {
		// TODO Auto-generated method stub
		return null;
	}
}
