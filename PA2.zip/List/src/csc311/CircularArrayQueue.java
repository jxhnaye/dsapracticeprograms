/**
 * 
 */
package csc311;

import net.datastructures.Queue;

/**
 * @author ruihong-adm
 * @param <E>
 *
 */

public class CircularArrayQueue<E> implements Queue<E> {
	
	private E[] data;
	private int h = 0;
	private int sz = 0;

	public CircularArrayQueue(int queueSize) {
		// TODO: create a new queue with the specified size
		data = (E[]) new Object[queueSize];
	}
	
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return sz;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return (sz == 0);
	}

	@Override
	public void enqueue(E e) throws IllegalStateException {
		if(sz == data.length) {
			throw new IllegalStateException("Queue full!");
		}
		int avail = (h + sz) % data.length;
		data[avail] = e;
		sz++;
		// TODO Auto-generated method stub
		
	}

	@Override
	public E first() {
		// TODO Auto-generated method stub
		if(isEmpty()) {
			return null;
		}
		return data[h];
	}

	@Override
	public E dequeue() {
		// TODO Auto-generated method stub
		if(isEmpty()) {
			return null;
		}
		E ans = data[h];
		data[h] = null;
		h = (h + 1) % data.length;
		sz--;
		return ans;
	}
    
}
