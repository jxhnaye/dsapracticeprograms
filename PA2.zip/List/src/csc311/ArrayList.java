package csc311;

import java.util.Iterator;

import net.datastructures.List;

public class ArrayList<E> implements List<E> {

	public static final int CAPACITY = 16;
	private E[] data;
	private int size = 0;
	
	public ArrayList() {
		this(CAPACITY);
		// TODO Auto-generated constructor stub
		
	}
	
	public ArrayList(int capacity) {
		data = (E[]) new Object[capacity];
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return size == 0;
	}

	@Override
	public E get(int i) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		checkIndex(i, size);
		return data[i];
	}

	@Override
	public E set(int i, E e) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		checkIndex(i, size);
		E temp = data[i];
		data[i] = e;
		return temp;
	}

	@Override
	public void add(int i, E e) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		checkIndex(i, size + 1);
		if(size == data.length) {
			resize();
		}
		for(int k = size - 1; k >= i; k--) {
			data[k + 1] = data[k];
			data[i] = e;
			size++;
		}
	}
	
	@Override
	public E remove(int i) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		checkIndex(i, size);
		E temp = data[i];
		for(int k = i; i < size - 1; k ++) {
			data[k] = data[k + 1];
			data[size - 1] = null;
			size--;
		}
		return temp;
	}

	
	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return new ArrayIterator();
	}

	public void addFirst(E e)  {
		// TODO Auto-generated method stub
		add(0, e);
	}
	
	public void addLast(E e)  {
		// TODO Auto-generated method stub
		add(size, e);
	}
	
	public E removeFirst() throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		return this.remove(0);
	}
	
	public E removeLast() throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		return this.remove(size - 1);
	}
	
	// Return the capacity of array, not the number of elements.
	// Notes: The initial capacity is 16. When the array is full, the array should be doubled. 
	public int capacity() {
		if(data[data.length - 1] == null) {
			return CAPACITY;
		}
		for(int i = 0; i < data.length; i++) {
			if(i == data.length - 1) {
				resize();	
		}
	}
		return data.length;
	}

	public void resize() {
		E[] temp = (E[])new Object[CAPACITY * 2];
		for(int j = 0; j < size; j++ ) {
			temp[j] = data[j];
		}
		data = temp;
	}
	
	// check if an index is within bounds of list
	
	public void checkIndex(int i, int n) throws IndexOutOfBoundsException {
		if(i < 0 || i >= n) {
			throw new IndexOutOfBoundsException("Index out of bounds: " + i);
		}
	}
	
	// nested class to create an iterator
	
	private class ArrayIterator implements Iterator {
		private int i = 0;
		private boolean removeable = false;
		
		public boolean hasNext() {
			return i < size;
		}
		
		//gets next element
		public E next() throws IndexOutOfBoundsException {
			if(i == size) {
				throw new IndexOutOfBoundsException("No next element");
			}
			removeable = true;
			return data[i++];
		}
		
		public void remove() throws IllegalStateException {
			if(!removeable) {
				throw new IllegalStateException("nothing to remove");
			}
				data[i - 1] = null;
				i--;
				removeable = false;
			}
	
}
}

