package csc311;

public class InPlaceHeapSort<K extends Comparable<K>> implements Sorter<K> {

	/**
	 * sort - Perform an in-place heap sort
	 * @param array - Array to sort
	 */
private int size;
	
	public void sort(K[] array) {
		size = array.length;
		for(int i = (array.length / 2) - 1; i >=0; i--) {
			maxHeap(array, i);
		}
		
		for(int i = array.length - 1; i>= 1; i--) {
			K k = array[i];
			array[i] = array[0];
			array[0] = k;
			size--;
			maxHeap(array, 0);
		}
	}
		
	private void maxHeap(K[] a, int index) {
		int largest = index;
		int left = index * 2 + 1;
		int right = index * 2 + 2;
		
		if(left < size && a[left].compareTo(a[largest]) > 0) {
			largest = left;
		}
		
		if(right < size && a[right].compareTo(a[largest]) > 0) {
			largest = right;
		}
		
		if(largest != index) {
			K k = a[index];
			a[index] = a[largest];
			a[largest] = k;
			maxHeap(a, largest);
		}
		return;
		
	}
}
