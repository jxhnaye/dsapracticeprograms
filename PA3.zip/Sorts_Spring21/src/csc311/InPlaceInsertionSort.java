package csc311;

public class InPlaceInsertionSort<K extends Comparable<K>> implements Sorter<K> {

	/**
	 * sort - Perform an in-place insertion sort
	 * @param array - Array to sort
	 */
	
	public void sort(K[] array) {
		for(int i = 1; i < array.length; i++) {
			K x = array[i];
			int j = i -1;
			
			while(j >= 0 && array[j].compareTo(x) > 0) {
				array[j + 1] = array [j];
				j--;
			}
			array[j + 1] = x;
		}
	}
	}

