package csc311;

public class InPlaceSelectionSort<K extends Comparable<K>> implements Sorter<K> {

	/**
	 * sort - Perform an in-place selection sort
	 * @param array - Array to sort
	 */
	
	public void sort(K[] array) {
	for(int i = 0; i < array.length; i++) {
		int min = i;
		
		for(int j = i; j < array.length; j++) {
			if(array[j].compareTo(array[min]) < 0) {
				min = j;
			}
		}
		K temp = array[i];
		array[i] = array[min];
		array[min] = temp;
	}
	}
}
